"""Create a separate BLJS10050 localization from the user's installed game."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import sys
import tempfile
import zlib

from delta_codec import load_delta

ROOT = Path(__file__).resolve().parent
CHUNK = 4 * 1024**2


def require(ok, msg):
    if not ok:
        raise ValueError(msg)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def table(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def patched(data, key, final_size, final_hash):
    if sha(data) == final_hash:
        return data
    if key is None:
        raise ValueError("지원하지 않는 파일 내용입니다.")
    if key.startswith("gdp:"):
        key = key[4:]
        result, length = load_delta(ROOT / "delta" / key, key, data)
        require(length == final_size, "번역 길이 검증 실패")
    else:
        blob = (ROOT / "delta" / key).read_bytes()
        require(sha(blob) == key, "차분 파일이 손상됐습니다.")
        diff = zlib.decompress(blob)
        require(len(diff) == len(data), "입력 파일의 길이가 다릅니다.")
        result = (int.from_bytes(data, "little") ^ int.from_bytes(diff, "little")).to_bytes(len(data), "little")
    require(sha(result[:final_size]) == final_hash, "한국어 결과 해시 검증 실패")
    return result


def disc_plan(src):
    spec = table("disc.json")
    require(src.seek(0, 2) == spec["size"], "BLJS10050의 전체 game.arb를 선택해 주세요.")
    src.seek(0)
    header = bytearray(src.read(spec["index_size"]))
    normalized = header.copy()
    result_header = header.copy()
    changes = []
    for name, entry in spec["entries"].items():
        pos = entry["index"]
        off, size, _, width, nlen = struct.unpack_from(">IIIHH", header, pos)
        require(width >= 17+nlen and header[pos+17:pos+17+nlen] == name.encode() and
                off + len(header) == entry["offset"] and 0 < size <= entry["capacity"],
                "디스크 색인 불일치 " + name)
        src.seek(entry["offset"])
        data = src.read(size)
        checksum = sha(data)
        require(checksum == entry["final"] or checksum in entry["from"],
                "지원하지 않는 버전의 번역 항목 " + name)
        result = patched(data, entry["from"].get(checksum), entry["length"], entry["final"])
        if checksum != entry["final"]:
            changes.append((entry["offset"], result, checksum))
        struct.pack_into(">I", normalized, pos+4, entry["capacity"])
        struct.pack_into(">I", result_header, pos+4, entry["length"])
    require(sha(normalized) == spec["clean_index"] and sha(result_header) == spec["final_index"],
            "지원하지 않는 디스크 색인입니다.")
    if result_header != header:
        changes.append((0, result_header, sha(header)))
    return sorted(changes)


def write_disc(src, path, changes):
    src.seek(0)
    before = os.fstat(src.fileno())
    expected = hashlib.sha256()
    position = 0
    with path.open("xb") as dst:
        def write(data):
            dst.write(data)
            expected.update(data)
        for start, replacement, old_hash in changes:
            require(start >= position, "디스크 패치 위치가 겹칩니다.")
            while position < start:
                fragment = src.read(min(CHUNK, start-position))
                require(fragment, "디스크 파일이 잘렸습니다.")
                write(fragment)
                position += len(fragment)
            require(sha(src.read(len(replacement))) == old_hash, "디스크 입력이 작업 중 바뀌었습니다.")
            write(replacement)
            position += len(replacement)
        while block := src.read(CHUNK):
            write(block)
        dst.flush()
        os.fsync(dst.fileno())
    after = os.fstat(src.fileno())
    require((before.st_size, before.st_mtime_ns) == (after.st_size, after.st_mtime_ns),
            "작업 중 디스크 파일이 변경되었습니다.")
    actual = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(CHUNK):
            actual.update(block)
    require(path.stat().st_size == before.st_size and actual.digest() == expected.digest(), "디스크 출력 파일 검증 실패")


def install(game, patch, parent):
    output = parent / "0081_KO_v0.5"
    require(not output.exists(), "출력 폴더가 이미 있습니다. 다른 상위 폴더를 선택해 주세요. " + str(output))
    parent.mkdir(exist_ok=True, parents=True)
    updates = table("updates.json") if patch is not None else {}
    needed = game.stat().st_size + sum(e["size"] for e in updates.values())
    require(shutil.disk_usage(parent).free >= needed + CHUNK, "출력 드라이브에 약 4GB의 여유 공간이 필요합니다.")
    with game.open("rb") as src:
        plan = disc_plan(src)
        stage = Path(tempfile.mkdtemp(prefix=".0081_ko_", dir=parent))
        try:
            if updates:
                (stage / "patch").mkdir()
            for name, entry in updates.items():
                p = patch / name
                require(p.is_file() and p.stat().st_size == entry["size"],
                        "순정 또는 기체 모드가 없는 한글 업데이트 파일이 필요합니다. " + name)
                data = p.read_bytes()
                out = patched(data, entry["from"].get(sha(data)), entry["size"], entry["final"])
                dest = stage / "patch" / name
                dest.write_bytes(out)
                require(sha(dest.read_bytes()) == entry["final"], "업데이트 출력 검증 실패 " + name)
            print("본편을 복사하고 번역 데이터를 검증합니다.", flush=True)
            write_disc(src, stage / "game.arb", plan)
            stage.rename(output)
        finally:
            if stage.exists():
                shutil.rmtree(stage)
    return output


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--game", type=Path)
    ap.add_argument("--patch", type=Path)
    ap.add_argument("--out", type=Path)
    args = ap.parse_args()
    if any((args.game, args.patch, args.out)):
        if not args.game or not args.out:
            ap.error("--game과 --out을 함께 지정하세요. 1.02는 --patch로 patch 폴더도 지정하세요.")
        return install(args.game, args.patch, args.out)

    from tkinter import Tk, filedialog, messagebox
    root = Tk()
    root.withdraw()
    try:
        game = filedialog.askopenfilename(title="본편 PS3_GAME/USRDIR/game.arb 선택", parent=root,
                                         filetypes=[("건담전기 본편", "*.arb")])
        if not game:
            return
        patch = None
        use_update = messagebox.askyesnocancel("업데이트", "버전 1.02용 업데이트도 한글화할까요?\n1.02는 예, 디스크 본편만 사용하면 아니요를 선택하세요.", parent=root)
        if use_update is None:
            return
        if use_update:
            folder = filedialog.askdirectory(title="patch0100·0200_arb.sdat가 있는 원본 patch 폴더 선택", parent=root)
            if not folder:
                return
            patch = Path(folder)
        folder = filedialog.askdirectory(title="수정본을 만들 출력 위치 선택", parent=root)
        if folder:
            out = install(Path(game), patch, Path(folder))
            messagebox.showinfo("완료", f"검증한 파일을 만들었습니다.\n{out}\n설치.txt에 따라 게임에 복사하세요.", parent=root)
            return out
    finally:
        root.destroy()


if __name__ == "__main__":
    try:
        out = main()
        if out:
            print("완료", out)
    except (OSError, ValueError, RuntimeError, struct.error, zlib.error) as exc:
        sys.exit("패치 실패. " + str(exc))
