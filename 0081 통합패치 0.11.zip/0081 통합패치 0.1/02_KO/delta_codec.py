import hashlib, struct, zlib

def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_exact(stream, size):
    value = stream.read(size)
    if len(value) != size:
        raise ValueError('Unexpected end of file / 파일이 잘렸습니다.')
    return value


def load_delta(path, expected_hash, original):
    compressed = path.read_bytes()
    if digest(compressed) != expected_hash:
        raise ValueError('Patch data damaged / 패치 데이터 손상: ' + path.name)
    dec = zlib.decompressobj()
    raw = dec.decompress(compressed, 64 * 1024 * 1024)
    if not dec.eof or dec.unused_data or dec.unconsumed_tail:
        raise ValueError('Invalid delta compression')
    if raw[:6] != b'GDKO1\0' or len(raw) < 18:
        raise ValueError('Invalid delta signature')
    allocation, logical_size, count = struct.unpack_from('>III', raw, 6)
    if allocation != len(original) or not 0 < logical_size <= allocation:
        raise ValueError('Invalid delta allocation')
    patched = bytearray(original)
    pos = 18
    previous_end = 0
    for _ in range(count):
        if pos + 8 > len(raw):
            raise ValueError('Truncated delta')
        off, size = struct.unpack_from('>II', raw, pos)
        pos += 8
        if not size or off < previous_end or off + size > allocation or pos + size > len(raw):
            raise ValueError('Delta range exceeds original allocation')
        patched[off:off + size] = raw[pos:pos + size]
        pos += size
        previous_end = off + size
    if pos != len(raw):
        raise ValueError('Unexpected delta trailing data')
    return bytes(patched), logical_size
