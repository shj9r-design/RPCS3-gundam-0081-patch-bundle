@echo off
setlocal
chcp 65001 >nul
where py >nul 2>nul
if errorlevel 1 goto usepython
py -3 -B -X utf8 "%~dp0install_ko.py" %*
goto done
:usepython
python -B -X utf8 "%~dp0install_ko.py" %*
:done
set "rc=%errorlevel%"
pause
exit /b %rc%
