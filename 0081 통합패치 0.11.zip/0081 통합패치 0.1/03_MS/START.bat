@echo off
setlocal
chcp 65001 >nul
set "launcher=py -3"
where py >nul 2>nul
if errorlevel 1 set "launcher=python"
%launcher% -c "import cryptography, zstandard" >nul 2>nul
if errorlevel 1 goto isolated
%launcher% -B -X utf8 "%~dp0install_ms.py" %*
goto done
:isolated
set "venvpy=%~dp0.ms_env\Scripts\python.exe"
if exist "%venvpy%" goto dependencies
%launcher% -m venv "%~dp0.ms_env"
if errorlevel 1 goto done
:dependencies
"%venvpy%" -c "import cryptography, zstandard" >nul 2>nul
if not errorlevel 1 goto apply
echo 기체 패치에 필요한 모듈을 패키지 폴더에 설치합니다.
"%venvpy%" -m pip install cryptography zstandard
if errorlevel 1 goto done
:apply
"%venvpy%" -B -X utf8 "%~dp0install_ms.py" %*
:done
set "rc=%errorlevel%"
pause
exit /b %rc%
