"""Build the translated MS MOD update against the user's localization-only SDAT."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
NAME = "patch0200_arb.sdat"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def hash_file(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        while block := f.read(4 * 1024**2):
            h.update(block)
    return h.hexdigest()


def encode_to(src_data, reader, size, dest):
    from sdat import aes, cmac, info, EDAT_KEY
    block, _, _, key, hash_key, _, src_end = info(src_data)
    header = bytearray(src_data[:0x100])
    struct.pack_into(">Q", header, 0x88, size)
    header[0xb0:] = bytes(0x50)
    count = (size+block-1)//block
    tags = bytearray(16*count)
    dest.seek(len(header)+len(tags))
    for index in range(count):
        n = min(block, size-index*block)
        plain = reader.read(n)
        require(len(plain)==n, "기체 차분 복원이 중단됐습니다.")
        material = header[0x60:0x6c] + struct.pack(">I", index)
        final_key = aes(EDAT_KEY, aes(key, material, encrypt=True), bytes(16))
        enc = aes(final_key, plain + bytes((-n) % 16), header[0x40:0x50], encrypt=True)
        tags[16*index:16*index+16] = cmac(final_key, enc)
        dest.write(enc)
    require(not reader.read(1), "복원된 기체 데이터 길이 오류")
    dest.write(src_data[src_end:])
    header[0x90:0xa0] = cmac(hash_key, bytes(tags))
    header[0xa0:0xb0] = cmac(hash_key, bytes(header[:0xa0]))
    dest.seek(0)
    dest.write(header)
    dest.write(tags)
    dest.flush()
    os.fsync(dest.fileno())


def install(source, parent):
    import zstandard as zstd
    from sdat import decode

    spec = json.loads((ROOT/"models.json").read_text(encoding="utf8"))
    checksum = hash_file(source)
    if checksum == spec["final_sdat"]:
        return "이미 한글화와 MS MOD v0.014가 적용된 파일입니다."
    require(checksum == spec["base_sdat"], "한글 기본 패치가 생성한 patch0200_arb.sdat를 선택해 주세요.")
    delta = ROOT/"models.zst"
    require(hash_file(delta) == spec["delta_sha256"], "기체 차분 파일이 손상됐습니다.")
    parent.mkdir(parents=True, exist_ok=True)
    final = parent/"0081_MS_MOD_v0.014_KO"
    if final.exists():
        require((final/NAME).is_file() and hash_file(final/NAME)==spec["final_sdat"],
                "출력 폴더에 다른 파일이 있습니다. 다른 위치를 선택해 주세요.")
        return "이미 생성한 파일입니다. " + str(final/NAME)
    require(shutil.disk_usage(parent).free >= spec["final_size"]+1024**2, "출력 공간이 부족합니다.")
    source_data = source.read_bytes()
    require(hashlib.sha256(source_data).hexdigest() == checksum, "입력이 변경됐습니다.")
    dictionary = zstd.ZstdCompressionDict(decode(source_data), dict_type=zstd.DICT_TYPE_RAWCONTENT)
    decoder = zstd.ZstdDecompressor(dict_data=dictionary, max_window_size=256*1024*1024)
    stage = Path(tempfile.mkdtemp(prefix=".msmod_", dir=parent))
    try:
        print("한국어 업데이트를 바탕으로 기체 모델과 장비 데이터를 생성합니다.", flush=True)
        with delta.open("rb") as patch, decoder.stream_reader(patch) as reader, (stage/NAME).open("xb") as result:
            encode_to(source_data, reader, spec["plaintext_size"], result)
        require(hash_file(stage/NAME) == spec["final_sdat"], "기체 모드 최종 SHA-256 검증 실패")
        stage.rename(final)
    finally:
        if stage.exists():
            shutil.rmtree(stage)
    return "생성 및 검증 완료\n" + str(final/NAME)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", type=Path)
    ap.add_argument("--out", type=Path)
    a = ap.parse_args()
    if a.source or a.out:
        if not a.source or not a.out:
            ap.error("--source와 --out이 모두 필요합니다.")
        print(install(a.source, a.out))
        return
    from tkinter import Tk, filedialog, messagebox
    root = Tk()
    root.withdraw()
    try:
        f = filedialog.askopenfilename(title="한글 기본판의 patch0200_arb.sdat 선택", parent=root, filetypes=[("업데이트", "*.sdat")])
        if f:
            dest = filedialog.askdirectory(title="출력 위치 선택", parent=root)
            if dest:
                msg = install(Path(f), Path(dest))
                print(msg)
                messagebox.showinfo("MS MOD", msg, parent=root)
    finally:
        root.destroy()


if __name__ == "__main__":
    try:
        main()
    except ImportError:
        sys.exit("기체 패치에 cryptography와 zstandard가 필요합니다. START.bat로 실행해 주세요.")
    except (OSError, ValueError, RuntimeError, struct.error) as exc:
        sys.exit("패치 실패. " + str(exc))
