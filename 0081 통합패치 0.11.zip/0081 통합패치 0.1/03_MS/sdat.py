import struct
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.cmac import CMAC

SDAT_KEY = bytes.fromhex('0d655ef8e674a98ab8505cfa7d012933')
EDAT_KEY = bytes.fromhex('be959ca8308defa2e5e180c63712a9ae')

def aes(key, data, iv=None, encrypt=False):
    mode = modes.ECB() if iv is None else modes.CBC(iv)
    cipher = Cipher(algorithms.AES(key), mode)
    ctx = cipher.encryptor() if encrypt else cipher.decryptor()
    return ctx.update(data) + ctx.finalize()

def cmac(key, data):
    ctx = CMAC(algorithms.AES(key))
    ctx.update(data)
    return ctx.finalize()

def info(data):
    if data[:4] != b'NPD\0': raise ValueError('SDAT 헤더 오류')
    if struct.unpack_from('>I', data, 4)[0] != 2: raise ValueError('SDAT 버전 오류')
    flags, block, size = struct.unpack_from('>IIQ', data, 0x80)
    if flags != 0x0100000c or block != 0x4000: raise ValueError('SDAT 형식 오류')
    count = (size + block - 1) // block
    key = bytes(a ^ b for a, b in zip(data[0x60:0x70], SDAT_KEY))
    hash_key = aes(EDAT_KEY, key, bytes(16))
    data_start = 0x100 + 16 * count
    end = data_start + ((size + 15) & ~15)
    if len(data) < end: raise ValueError('SDAT 크기 오류')
    return block, size, count, key, hash_key, data_start, end

def decode(data):
    block, size, count, key, hash_key, start, end = info(data)
    if cmac(hash_key, data[:0xa0]) != data[0xa0:0xb0]: raise ValueError('Header CMAC')
    if cmac(hash_key, data[0x100:start]) != data[0x90:0xa0]: raise ValueError('Metadata CMAC')
    out = bytearray()
    for i in range(count):
        block_key = aes(key, data[0x60:0x6c] + struct.pack('>I', i), encrypt=True)
        final_key = aes(EDAT_KEY, block_key, bytes(16))
        enc = data[start + i * block:min(start + (i + 1) * block, end)]
        if cmac(final_key, enc) != data[0x100 + i * 16:0x110 + i * 16]: raise ValueError(f'Block CMAC {i}')
        out.extend(aes(final_key, enc, data[0x40:0x50]))
    return bytes(out[:size])

