"""Install the supplied Federation and Zeon firing samples in a new BLJS10050 archive."""
import hashlib
import os
import shutil
import struct
import sys
from pathlib import Path

PACKAGE = Path(__file__).resolve().parent
RATE = 48000
GAME_SIZE = 3573308160
BANK_INDEX = 156772
BANK_NAME = b'game/nu/nu_in_game.nub'
DATA_BASE = 274432
BANK_POS = 2344439216
BANK_SIZE = 4929328
SLOTS = {'연방': (32, 1570128, 29296), '지온': (33, 1599424, 31168)}
BLOCK = 4194304
BANK_MASKED_HASH = 'cfb14d43711c418436cc07980765accb7901b45ec373d1f93477937f507e6b84'
PAYLOAD_HASHES = {'fed.bin': 'fa7a7c84c3c9001db37fd137a2b64a298d475194cfd9abe5cbd276d71b8983f1', 'zeon.bin': '78d1477c4258803f90f36fa09e9d13d71dadf9eeac770f8ab0794f9c03863ba8'}


def bank_edits(src, waveforms):
    if os.fstat(src.fileno()).st_size != GAME_SIZE:
        raise ValueError('건담전기 0081 전체 game.arb를 선택해 주세요.')
    src.seek(0)
    if src.read(4) != b'BfPk':
        raise ValueError('0081 아카이브 헤더가 아닙니다.')
    src.seek(BANK_INDEX)
    index=src.read(17+len(BANK_NAME))
    offset,size,_,_,name_len=struct.unpack_from('>IIIHH',index)
    if (DATA_BASE+offset,size,index[17:],name_len)!=(BANK_POS,BANK_SIZE,BANK_NAME,len(BANK_NAME)):
        raise ValueError('전투 사운드 뱅크의 위치가 예상과 다릅니다.')
    src.seek(BANK_POS)
    bank=src.read(BANK_SIZE)
    # All bytes except the two replaceable samples must belong to this specific bank.
    masked = bytearray(bank)
    for _, off, length in SLOTS.values():
        start = 0x5000 + off
        masked[start:start+length] = bytes(length)
    if len(bank) != BANK_SIZE or hashlib.sha256(masked).hexdigest() != BANK_MASKED_HASH:
        raise ValueError('전투 사운드 뱅크가 확인한 버전과 다릅니다. 건담전기 0081 BLJS10050의 game.arb를 선택해 주세요.')
    edits=[]
    for side,(event,off,n) in SLOTS.items():
        h=struct.unpack_from('>I',bank,32+4*event)[0]
        if (bank[h:h+4],struct.unpack_from('>I',bank,h+8)[0],
            struct.unpack_from('>II',bank,h+20),struct.unpack_from('>I',bank,h+188)[0])!=(b'vag\0',event,(n,off),RATE):
            raise ValueError('발사음 슬롯 구조가 예상과 다릅니다.')
        new=waveforms[side]
        if len(new)!=n: raise ValueError('발사음 인코딩 크기가 다릅니다.')
        original = bank[0x5000+off:0x5000+off+n]
        if original != new:
            edits.append((BANK_POS+0x5000+off,original,new))
    return edits

def apply(source,destination,waveforms,notify=print):
    source,destination=Path(source),Path(destination)
    if source.resolve()==destination.resolve() or destination.exists():
        raise ValueError('출력에는 아직 존재하지 않는 새 파일 이름을 지정해 주세요.')
    expected=hashlib.sha256()
    created=False
    try:
        with source.open('rb') as src:
            st=os.fstat(src.fileno())
            edits=bank_edits(src,waveforms)
            if not edits:
                notify('이 두 발사음이 이미 적용되어 있습니다.')
                return None
            if shutil.disk_usage(destination.parent).free < GAME_SIZE+BLOCK:
                raise OSError('새 복사본을 만들려면 약 3.6 GB의 여유 공간이 필요합니다.')
            src.seek(0)
            notify('두 머신건 발사음을 적용한 새 game.arb를 만드는 중입니다.')
            with destination.open('xb') as dst:
                created=True
                def emit(buf):
                    if dst.write(buf)!=len(buf): raise OSError('출력 파일 쓰기 실패')
                    expected.update(buf)
                def copy_to(end):
                    while src.tell()<end:
                        buf=src.read(min(BLOCK,end-src.tell()))
                        if not buf: raise OSError('원본 파일이 중간에서 끝났습니다.')
                        emit(buf)
                for pos,old,new in edits:
                    copy_to(pos)
                    if src.read(len(old))!=old: raise ValueError('작업 중 원본 발사음이 바뀌었습니다.')
                    emit(new)
                copy_to(GAME_SIZE)
                dst.flush();os.fsync(dst.fileno())
            after=os.fstat(src.fileno())
            if (st.st_size,st.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):
                raise ValueError('작업 중 원본이 바뀌었습니다.')
        notify('완성 파일 전체를 다시 읽어 확인하고 있습니다.')
        verify=hashlib.sha256()
        with destination.open('rb') as dst:
            while chunk:=dst.read(BLOCK): verify.update(chunk)
        if destination.stat().st_size!=GAME_SIZE or verify.digest()!=expected.digest():
            raise OSError('완성 파일 검증 실패')
    except BaseException:
        if created: destination.unlink(missing_ok=True)
        raise
    return expected.hexdigest()


def load_samples():
    samples = {}
    for side, name in [('연방', 'fed.bin'), ('지온', 'zeon.bin')]:
        data = (PACKAGE / name).read_bytes()
        if hashlib.sha256(data).hexdigest() != PAYLOAD_HASHES[name]:
            raise ValueError(name + ' 내용이 손상되었습니다. ZIP을 다시 풀어 주세요.')
        samples[side] = data
    return samples


def main():
    root = None
    try:
        if len(sys.argv) == 3:
            source, destination = sys.argv[1:]
        elif len(sys.argv) == 1:
            import tkinter as tk
            from tkinter import filedialog, messagebox
            root = tk.Tk()
            root.withdraw()
            root.attributes('-topmost', True)
            source = filedialog.askopenfilename(parent=root, title='1/2 현재 플레이 중인 건담전기 0081 game.arb 선택',
                                                filetypes=[('게임 아카이브', '*.arb'), ('모든 파일', '*.*')])
            if not source:
                return
            destination = filedialog.asksaveasfilename(parent=root, title='2/2 새 패치본을 저장할 위치 선택',
                     initialdir=str(Path(source).parent), initialfile='game_mg_gbo2_v2.arb', defaultextension='.arb',
                     filetypes=[('게임 아카이브', '*.arb')])
            if not destination:
                return
        else:
            raise ValueError('사용법: py -3 apply_mg.py "원본 game.arb" "새 출력 파일.arb"')
        digest = apply(source, destination, load_samples(), notify=lambda s: print(s, flush=True))
        if digest is None:
            if root: messagebox.showinfo('이미 적용됨', '두 발사음이 이미 적용되어 있습니다.', parent=root)
            return
        print('검증 완료. 출력 SHA-256', digest)
        print(destination)
        if root:
            messagebox.showinfo('발사음 패치 생성 완료',
                str(destination) + '\n\n기존 game.arb를 게임 밖에 백업하고, 완성 파일을 game.arb로 바꾸어 넣으세요.', parent=root)
    except Exception as exc:
        if root: messagebox.showerror('발사음 패치 오류', str(exc), parent=root)
        raise
    finally:
        if root: root.destroy()


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, ImportError) as exc:
        sys.exit('오류: ' + str(exc))
