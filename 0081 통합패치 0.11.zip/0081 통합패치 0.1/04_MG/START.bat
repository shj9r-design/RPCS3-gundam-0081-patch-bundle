@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
set PYTHONUTF8=1
where py >nul 2>nul
if errorlevel 1 goto try_python
py -3 -X utf8 "%~dp0apply_mg.py"
goto done
:try_python
where python >nul 2>nul
if errorlevel 1 goto no_python
python -X utf8 "%~dp0apply_mg.py"
goto done
:no_python
echo Python 3.10 or newer is required.
:done
echo.
pause
